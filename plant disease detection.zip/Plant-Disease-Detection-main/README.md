# Plant-Disease-Detection



### Steps to run Code
- Clone the repository.
```
git clone https://github.com/soikotbiswas/plant_disease_detection-
```
- Goto the cloned folder.
```
cd Plant-Disease-Detection

```
- Upgrade pip with the mentioned command below.
```
pip install --upgrade pip
```
- Install requirements with the mentioned command below.
```
pip install -r requirements.txt
```
- Run the code with the mentioned command below.

streamlit run app.py 
 



